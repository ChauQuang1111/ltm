﻿namespace Lab4_Assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.boxPassword = new System.Windows.Forms.TextBox();
            this.boxUsername = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.boxPort = new System.Windows.Forms.TextBox();
            this.boxGmail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnChooseFile = new System.Windows.Forms.Button();
            this.btnChooseList = new System.Windows.Forms.Button();
            this.boxMessage = new System.Windows.Forms.TextBox();
            this.boxTitle = new System.Windows.Forms.TextBox();
            this.boxFile = new System.Windows.Forms.TextBox();
            this.boxMailTo = new System.Windows.Forms.TextBox();
            this.boxMailFrom = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.boxPassword);
            this.groupBox1.Controls.Add(this.boxUsername);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(36, 36);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(413, 126);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Login Setting";
            // 
            // boxPassword
            // 
            this.boxPassword.Location = new System.Drawing.Point(117, 75);
            this.boxPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxPassword.Name = "boxPassword";
            this.boxPassword.Size = new System.Drawing.Size(236, 22);
            this.boxPassword.TabIndex = 3;
            this.boxPassword.Text = "nguginoi123";
            this.boxPassword.UseSystemPasswordChar = true;
            // 
            // boxUsername
            // 
            this.boxUsername.Location = new System.Drawing.Point(117, 28);
            this.boxUsername.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxUsername.Name = "boxUsername";
            this.boxUsername.Size = new System.Drawing.Size(236, 22);
            this.boxUsername.TabIndex = 2;
            this.boxUsername.Text = "viet.tran.cit20@eiu.edu.vn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.boxPort);
            this.groupBox2.Controls.Add(this.boxGmail);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(559, 36);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(413, 126);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SMTP Settings";
            // 
            // boxPort
            // 
            this.boxPort.Location = new System.Drawing.Point(117, 75);
            this.boxPort.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxPort.Name = "boxPort";
            this.boxPort.Size = new System.Drawing.Size(236, 22);
            this.boxPort.TabIndex = 3;
            this.boxPort.Text = "587";
            // 
            // boxGmail
            // 
            this.boxGmail.Location = new System.Drawing.Point(117, 28);
            this.boxGmail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxGmail.Name = "boxGmail";
            this.boxGmail.Size = new System.Drawing.Size(236, 22);
            this.boxGmail.TabIndex = 2;
            this.boxGmail.Text = "smtp.gmail.com";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 79);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Port";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 32);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Gmail";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnSend);
            this.groupBox3.Controls.Add(this.btnChooseFile);
            this.groupBox3.Controls.Add(this.btnChooseList);
            this.groupBox3.Controls.Add(this.boxMessage);
            this.groupBox3.Controls.Add(this.boxTitle);
            this.groupBox3.Controls.Add(this.boxFile);
            this.groupBox3.Controls.Add(this.boxMailTo);
            this.groupBox3.Controls.Add(this.boxMailFrom);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Location = new System.Drawing.Point(36, 186);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(935, 377);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Email Details";
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(729, 270);
            this.btnSend.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(147, 39);
            this.btnSend.TabIndex = 12;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnChooseFile
            // 
            this.btnChooseFile.Location = new System.Drawing.Point(729, 130);
            this.btnChooseFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChooseFile.Name = "btnChooseFile";
            this.btnChooseFile.Size = new System.Drawing.Size(147, 39);
            this.btnChooseFile.TabIndex = 11;
            this.btnChooseFile.Text = "Choose File";
            this.btnChooseFile.UseVisualStyleBackColor = true;
            this.btnChooseFile.Click += new System.EventHandler(this.btnChooseFile_Click);
            // 
            // btnChooseList
            // 
            this.btnChooseList.Location = new System.Drawing.Point(729, 54);
            this.btnChooseList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnChooseList.Name = "btnChooseList";
            this.btnChooseList.Size = new System.Drawing.Size(147, 39);
            this.btnChooseList.TabIndex = 10;
            this.btnChooseList.Text = "Choose List";
            this.btnChooseList.UseVisualStyleBackColor = true;
            this.btnChooseList.Click += new System.EventHandler(this.btnChooseList_Click);
            // 
            // boxMessage
            // 
            this.boxMessage.Location = new System.Drawing.Point(117, 228);
            this.boxMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxMessage.Multiline = true;
            this.boxMessage.Name = "boxMessage";
            this.boxMessage.Size = new System.Drawing.Size(512, 141);
            this.boxMessage.TabIndex = 9;
            // 
            // boxTitle
            // 
            this.boxTitle.Location = new System.Drawing.Point(117, 175);
            this.boxTitle.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxTitle.Name = "boxTitle";
            this.boxTitle.Size = new System.Drawing.Size(512, 22);
            this.boxTitle.TabIndex = 8;
            // 
            // boxFile
            // 
            this.boxFile.Location = new System.Drawing.Point(117, 130);
            this.boxFile.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxFile.Name = "boxFile";
            this.boxFile.Size = new System.Drawing.Size(512, 22);
            this.boxFile.TabIndex = 7;
            // 
            // boxMailTo
            // 
            this.boxMailTo.Location = new System.Drawing.Point(117, 87);
            this.boxMailTo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxMailTo.Name = "boxMailTo";
            this.boxMailTo.Size = new System.Drawing.Size(512, 22);
            this.boxMailTo.TabIndex = 6;
            // 
            // boxMailFrom
            // 
            this.boxMailFrom.Location = new System.Drawing.Point(117, 39);
            this.boxMailFrom.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.boxMailFrom.Name = "boxMailFrom";
            this.boxMailFrom.Size = new System.Drawing.Size(512, 22);
            this.boxMailFrom.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 231);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Message";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(72, 178);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 16);
            this.label8.TabIndex = 3;
            this.label8.Text = "Title";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 134);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "File attached";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 91);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Email to";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 43);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Email from";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 608);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SMTP - Send Email List";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox boxPassword;
        private System.Windows.Forms.TextBox boxUsername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox boxPort;
        private System.Windows.Forms.TextBox boxGmail;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnChooseFile;
        private System.Windows.Forms.Button btnChooseList;
        private System.Windows.Forms.TextBox boxMessage;
        private System.Windows.Forms.TextBox boxTitle;
        private System.Windows.Forms.TextBox boxFile;
        private System.Windows.Forms.TextBox boxMailTo;
        private System.Windows.Forms.TextBox boxMailFrom;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}


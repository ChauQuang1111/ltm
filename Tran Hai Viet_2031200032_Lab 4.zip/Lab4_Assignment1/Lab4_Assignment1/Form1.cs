﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4_Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        

        private void btnSend_Click(object sender, EventArgs e)
        {
            var basicCredential = new NetworkCredential(boxUsername.Text,boxPassword.Text);
            SmtpClient client = new SmtpClient();
            client.Host = boxGmail.Text;
            client.Port = int.Parse(boxPort.Text);
            client.UseDefaultCredentials = false;
            client.EnableSsl = true;
            client.Credentials = basicCredential;

            MailMessage message = new MailMessage();
            message.From = new MailAddress(boxMailFrom.Text);
            string[] addresses = boxMailTo.Text.Split(new[] {" "}, StringSplitOptions.RemoveEmptyEntries);
            foreach(string s in addresses)
            {
                message.To.Add(s);
            }

            if (File.Exists(boxFile.Text))
            {
                Attachment attachment = new Attachment(boxFile.Text);
                message.Attachments.Add(attachment);
            }
            else
            {
                MessageBox.Show("No attachments found");
            }

            message.Subject = boxTitle.Text;
            message.SubjectEncoding = System.Text.Encoding.UTF8;

    

            message.Body = boxMessage.Text;
            message.BodyEncoding = System.Text.Encoding.UTF8;

            client.Send(message);
            message.Dispose();
            MessageBox.Show("Email Sent");

        }

        private void btnChooseList_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text Files (*.txt) | *.txt";
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                string[] addresses = File.ReadAllLines(ofd.FileName);
                foreach (string s in addresses)
                {
                    if (!String.IsNullOrEmpty(s))
                    { 
                        
                        boxMailTo.AppendText(s + " ");
                    }
                }
                {
                    
                }
            }
        }

        private void btnChooseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All Files (*.*) |*.*";
            if(ofd.ShowDialog()==DialogResult.OK)
            {
                boxFile.Text = ofd.FileName;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Assignment1
{
    public partial class Form1 : Form
    {
        RSAParameters RSAPublic;
        RSAParameters RSAPrivate;
        byte[] encryptedData;
        public Form1()
        {
            InitializeComponent();
            using(RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                RSAPublic = rsa.ExportParameters(false);
                RSAPrivate = rsa.ExportParameters(true);
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] dataEncrypt = Encoding.Unicode.GetBytes(txtPlain.Text);
                using(RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
                {
                    rsa.ImportParameters(RSAPublic);
                    encryptedData = rsa.Encrypt(dataEncrypt,false);
                    txtEncrypt.Text = Encoding.Unicode.GetString(encryptedData);
                }
            }
            catch (ArgumentNullException)
            {
                MessageBox.Show("Encryption Failed");
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                byte[] decyptedData;
                using(RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSAPrivate);
                    decyptedData = RSA.Decrypt(encryptedData,false);
                    txtDecrypt.Text=Encoding.Unicode.GetString(decyptedData);

                    
                }
            }
            catch(ArgumentNullException)
            {
                MessageBox.Show("Decryption Failed");
            }
        }
    }
}

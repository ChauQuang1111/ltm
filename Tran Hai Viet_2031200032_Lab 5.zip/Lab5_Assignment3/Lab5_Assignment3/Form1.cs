﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5_Assignment3
{
    public partial class AES : Form
    {
        byte[] myKey;
        byte[] myVector;
        byte[] encrypted;
        public AES()
        {
            InitializeComponent();
            using(Aes aes = Aes.Create())
            {
                myKey=aes.Key;
                myVector=aes.IV;
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            using(Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = myKey;
                aesAlg.IV = myVector;

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key,aesAlg.IV);
                using(MemoryStream msEncrypt = new MemoryStream())
                {
                    using(CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using(StreamWriter sw = new StreamWriter(csEncrypt))
                        {
                            sw.Write(txtPlain.Text);
                            
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                    
                }
                txtEncrypt.Text=Encoding.Unicode.GetString(encrypted);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            string plainText = null;
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = myKey;
                aesAlg.IV = myVector;

                ICryptoTransform decryptor = aesAlg.CreateDecryptor();
                using (MemoryStream msDecrypt = new MemoryStream(encrypted))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(csDecrypt))
                        {
                            plainText=sr.ReadToEnd();

                        }
                    
                    }
                    txtDecrypt.Text = plainText;

                }
       
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Thread[] threadArr;
        int numFile = 0;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Multiselect = true;
            ofd.Filter = "All Files(*.*)|*.*|Text Files (*.txt)|*.txt|Image Files (*.jpg, *.jpeg, *.png)|*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string extension = Path.GetExtension(ofd.FileName).ToLower();
                if(extension == ".txt" || extension == ".jpg" || extension == ".jpeg" || extension == ".png")
                {
                    string[] filePaths = ofd.FileNames;
                    numFile = filePaths.Length;
                    threadArr = new Thread[numFile];
                    for(int i=0;i<filePaths.Length;i++)
                    {
                        listBoxUpload.Items.Add(filePaths[i]);
                        threadArr[i] = new Thread(uploadFile);
                        threadArr[i].Start(filePaths[i]);
                    }
                    Thread t = new Thread(joinThread);
                    t.Start();
                }
                else
                {
                    MessageBox.Show("Wrong file type");
                }
            }
        }

        void joinThread()
        {
            for(int i=0;i<numFile;i++)
            {
                threadArr[i].Join();
            }
        }

        void uploadFile(object _filePath)
        {
            string filePath = (string) _filePath;
            string fileName = Path.GetFileName(filePath);

            Action _uploading = delegate
            {
                listBoxStatus.Items.Add("Uploading: " + fileName);
            };
            Action _finished = delegate
            {
                listBoxStatus.Items.Add("* Uploaded: "+fileName);
            };
            listBoxStatus.Invoke(_uploading);
            listBoxStatus.Invoke(_finished);
            copyFileFolder(filePath);
        }

        void copyFileFolder(string filePath)
        {
            string directory = "./Images/";
            var destination = new DirectoryInfo(directory);
            if(!destination.Exists )
            {
                destination.Create();
            }
            if(destination.Exists && File.Exists(directory + Path.GetFileName(filePath))  )
            {
                File.Delete(directory+Path.GetFileName(filePath));         
            }
            File.Copy(filePath, directory + Path.GetFileName(filePath));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Assignment2
{
    public partial class tcpClient : Form
    {
        
        public tcpClient()
        {
            InitializeComponent();
        }
        string selectedImagePath;
        TcpClient client;

        private void btnListen_Click(object sender, EventArgs e)
        {
            client = new TcpClient("127.0.0.1", 20000);

            
        }
    

        private async void button1_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.gif)|*.jpg; *.jpeg; *.png; *.gif";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedImagePath = openFileDialog.FileName;
                txtPath.Text = selectedImagePath;
  
            }
        }

        private async void btnSend_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedImagePath))
            {
                MessageBox.Show("Please select an image first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

          

            try
            {
                using (TcpClient client = new TcpClient())
                {
                    await client.ConnectAsync("127.0.0.1", 20000);

                    using (NetworkStream stream = client.GetStream())
                    {
                        // Load image from file
                        Image image = Image.FromFile(selectedImagePath);

                        // Convert image to byte array
                        MemoryStream ms = new MemoryStream();
                        image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                        byte[] imageData = ms.ToArray();


                        string fileName = Path.GetFileName(selectedImagePath);

                        byte[] fileNameBytes = Encoding.UTF8.GetBytes(fileName);
                        stream.Write(fileNameBytes, 0, fileNameBytes.Length);

                        // Send image data to server
                        await stream.WriteAsync(imageData, 0, imageData.Length);
                    }
                }

                MessageBox.Show("Image sent successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                client.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending image: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }
    


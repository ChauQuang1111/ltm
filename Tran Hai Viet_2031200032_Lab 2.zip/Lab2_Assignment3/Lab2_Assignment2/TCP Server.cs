﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Assignment2
{
    public partial class tcpServer : Form
    {
        public tcpServer()
        {
            InitializeComponent();
        }

        TcpListener server;
        TcpClient client;
        Thread listen;

        private void btnListen_Click(object sender, EventArgs e)
        {
            server = new TcpListener(IPAddress.Any, 20000);
            server.Start();
            Thread t = new Thread(Listen);
            t.Start();

     
        }

        private void Listen()
        {
            Byte[] buffer = new Byte[1024 * 1024];

            while (true)
            {
                try
                {
                    TcpClient client = server.AcceptTcpClient();
                    lbContent.Invoke(new Action(() =>
                    {
                        lbContent.Items.Add("Connected!" + Environment.NewLine);
                    }));

                    NetworkStream ns = client.GetStream();


                    string receivedFileName = Path.Combine(Path.GetFileName(Path.GetRandomFileName()) + ".jpg");

                    using (FileStream fs = File.Create(receivedFileName))
                    {
                        int bytesRead;
                        while ((bytesRead = ns.Read(buffer, 0, buffer.Length)) > 0)
                        {
              
                            fs.Write(buffer, 0, bytesRead);
                        }
                    }

                    lbContent.Invoke(new Action(() =>
                    {
                        lbContent.Items.Add("Image received and saved: " + receivedFileName + Environment.NewLine);
                    }));
                    ns.Close();
                    client.Close();
                }
                catch (Exception ex)
                {
                   
                    lbContent.Invoke(new Action(() =>
                    {
                        lbContent.Items.Add("Error: " + ex.Message + Environment.NewLine);
                    }));
                }
            }
        }








    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Assignment2
{
    public partial class tcpClient : Form
    {
        public tcpClient()
        {
            InitializeComponent();
        }

        TcpClient client;

        private void btnListen_Click(object sender, EventArgs e)
        {
            client = new TcpClient(txtIP.Text.ToString(), Int32.Parse(txtPort.Text));

            Thread t = new Thread(Listen);
            t.Start();
        }

        void Listen()
        {
            Byte[] bytes = new byte[256];

            NetworkStream ns = client.GetStream();
            while (true)
            {
                int thisRead = 0;
                string receivedData;
                while ((thisRead = ns.Read(bytes, 0, bytes.Length)) != 0)
                {
                    receivedData=Encoding.UTF8.GetString(bytes,0,bytes.Length);
                    listBoxContent.Invoke(new Action(() =>
                    {
                        listBoxContent.Items.Add("Server: " + receivedData + Environment.NewLine);
                    }));
                    Array.Clear(bytes, 0, bytes.Length);
                }
                client.Close();
            }
            

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            NetworkStream ns = client.GetStream();
            string text = txtText.Text;
            ns.Write(Encoding.UTF8.GetBytes(text), 0, Encoding.UTF8.GetBytes(text).Length);
            txtText.Clear();
        }
    }
}

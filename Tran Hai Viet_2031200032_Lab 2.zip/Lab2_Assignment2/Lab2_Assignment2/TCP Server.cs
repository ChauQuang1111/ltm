﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2_Assignment2
{
    public partial class tcpServer : Form
    {
        public tcpServer()
        {
            InitializeComponent();
        }

        TcpListener server;
        TcpClient client;

        private void btnListen_Click(object sender, EventArgs e)
        {
            server = new TcpListener(IPAddress.Parse(txtIP.Text), Int32.Parse(txtPort.Text));
            server.Start();

            listBoxContent.Items.Add("Waiting for connection"+Environment.NewLine);

            Thread t = new Thread(Listen);
            t.Start();
        }

        void Listen()
        {
            Byte[] bytes = new byte[256];
            while (true)
            {
                client = server.AcceptTcpClient();
                listBoxContent.Invoke(new Action(()=>{
                    listBoxContent.Items.Add("Connected"+Environment.NewLine);
                }));

                NetworkStream ns = client.GetStream();
                int packetLength = 0;
                string receivedData;
                while((packetLength=ns.Read(bytes,0,bytes.Length))!=0)
                {
                    receivedData = Encoding.UTF8.GetString(bytes,0,bytes.Length);
                    listBoxContent.Invoke(new Action(() =>
                    {
                        listBoxContent.Items.Add("Client: "+receivedData+Environment.NewLine);
                    }));
                    Array.Clear(bytes, 0, bytes.Length);
                }
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            NetworkStream ns = client.GetStream();
            string text = txtText.Text;
            ns.Write(Encoding.UTF8.GetBytes(text),0,Encoding.UTF8.GetBytes(text).Length);
            txtText.Clear();
        }
    }
}

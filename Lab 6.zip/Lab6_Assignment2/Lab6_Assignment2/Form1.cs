﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6_Assignment2
{
    public partial class Form1 : Form
    {
        private List<string> imagePaths = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string folderPath = dialog.SelectedPath;
                    txtPath.Text = folderPath;
                    imagePaths = Directory.GetFiles(folderPath, "*.*", 
                        SearchOption.TopDirectoryOnly)
                        .Where(f => f.EndsWith(".jpg") || f.EndsWith(".jpeg") 
                        || f.EndsWith(".png")).ToList();
                    lbImage.Items.Clear();
                    lbImage.Items.AddRange(imagePaths.ToArray());
                }
            }
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            using(OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Multiselect = true;
                ofd.Filter = "Image Files | *.png;*.jpg;*.jpeg";
                if(ofd.ShowDialog() == DialogResult.OK)
                {
                    txtPath.Text=ofd.FileName;
                    imagePaths = ofd.FileNames.ToList();
                    lbImage.Items.Clear() ;
                    lbImage.Items.AddRange(imagePaths.ToArray());
                }
            }
        }

        private void btnCompress_Click(object sender, EventArgs e)
        {
            if(imagePaths.Count == 0) {
                MessageBox.Show("Please select images first");
                return;
            }

            string prefix = txtPrefix.Text;
            foreach(string s in imagePaths)
            {
                CompressImage(s, (int)comboBoxRatio.SelectedIndex, prefix);
            }
            MessageBox.Show("Compression completed.");
        }

        private void CompressImage(string imagePath, int compressionRatio, string prefix)
        {
            string directory = Path.GetDirectoryName(imagePath);
            string fileName = Path.GetFileNameWithoutExtension(imagePath);
            string extension = Path.GetExtension(imagePath);

            string compressedImagePath = Path.Combine(directory, $"{prefix}{fileName}{extension}");
            using (Bitmap bm = new Bitmap(imagePath))
            {
                ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
                System.Drawing.Imaging.Encoder qualityEncoder = System.Drawing.Imaging.Encoder.Quality;
                EncoderParameters encoderParameters = new EncoderParameters(1);
                encoderParameters.Param[0] = new EncoderParameter(qualityEncoder, compressionRatio);
                bm.Save(compressedImagePath,jpgEncoder,encoderParameters);
            }
        }
        private ImageCodecInfo GetEncoder(ImageFormat format)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.FormatID == format.Guid)
                {
                    return codec;
                }
            }
            return null;
        }
    }
}

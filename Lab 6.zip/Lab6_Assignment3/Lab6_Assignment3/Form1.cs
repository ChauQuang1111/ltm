﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6_Assignment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    txtPath.Text = dialog.SelectedPath;
                }
            }
        }

        private void btnCompress_Click(object sender, EventArgs e)
        {
            string folderPath = txtPath.Text;
           
            using(OpenFileDialog ofd = new OpenFileDialog()) { }
            string zipPath = Path.Combine(Path.GetDirectoryName(folderPath), Path.GetFileName(folderPath) + ".zip");
            ZipFile.CreateFromDirectory(folderPath, zipPath);
            MessageBox.Show($"Folder compressed to {zipPath}");
        }

        private void btnFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "Zip files (*.zip)|*.zip";
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    txtCompressPath.Text = dialog.FileName;
                }
            }
        }

        private void btnExtract_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string zipFilePath = txtCompressPath.Text;
                    string extractPath = dialog.SelectedPath;

                    if (string.IsNullOrEmpty(zipFilePath) || !File.Exists(zipFilePath))
                    {
                        MessageBox.Show("Please select a valid zip file.");
                        return;
                    }

                    if (string.IsNullOrEmpty(extractPath))
                    {
                        MessageBox.Show("Please select a valid extraction folder.");
                        return;
                    }

                    ZipFile.ExtractToDirectory(zipFilePath, extractPath);
                    MessageBox.Show($"Contents extracted to {extractPath}");
                }
            }
        }
    }
}

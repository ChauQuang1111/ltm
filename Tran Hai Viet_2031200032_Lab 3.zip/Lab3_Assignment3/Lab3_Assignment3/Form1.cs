﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_Assignment3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnGet_Click(object sender, EventArgs e)
        {
            string serverURL = boxURL.Text;
            using (HttpClient client = new HttpClient())
            {
                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>(boxParameter.Text, boxValue.Text)
                });
                try
                {
                    HttpResponseMessage response = await client.PostAsync(serverURL, content);
                    if (response.IsSuccessStatusCode)
                    {
                        // Read and display the response content
                        string responseData = await response.Content.ReadAsStringAsync();
                        boxContent.AppendText(responseData + Environment.NewLine);
                    }
                    else
                    {
                        boxContent.AppendText("Failed to retrieved data");
                    }
                }
                catch(Exception ex) {
                    boxContent.AppendText(ex.Message);
                }
            }
        }
    }
}

﻿namespace Lab3_Assignment3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.boxURL = new System.Windows.Forms.TextBox();
            this.boxParameter = new System.Windows.Forms.TextBox();
            this.boxValue = new System.Windows.Forms.TextBox();
            this.btnGet = new System.Windows.Forms.Button();
            this.boxContent = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "URL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Parameter";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(319, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Value";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Content";
            // 
            // boxURL
            // 
            this.boxURL.Location = new System.Drawing.Point(43, 40);
            this.boxURL.Multiline = true;
            this.boxURL.Name = "boxURL";
            this.boxURL.Size = new System.Drawing.Size(506, 27);
            this.boxURL.TabIndex = 4;
            this.boxURL.Text = "http://139.180.213.49/getdata.php";
            // 
            // boxParameter
            // 
            this.boxParameter.Location = new System.Drawing.Point(43, 121);
            this.boxParameter.Multiline = true;
            this.boxParameter.Name = "boxParameter";
            this.boxParameter.Size = new System.Drawing.Size(127, 24);
            this.boxParameter.TabIndex = 5;
            this.boxParameter.Text = "type";
            // 
            // boxValue
            // 
            this.boxValue.Location = new System.Drawing.Point(322, 121);
            this.boxValue.Multiline = true;
            this.boxValue.Name = "boxValue";
            this.boxValue.Size = new System.Drawing.Size(133, 24);
            this.boxValue.TabIndex = 6;
            this.boxValue.Text = "all";
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(43, 164);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(506, 30);
            this.btnGet.TabIndex = 7;
            this.btnGet.Text = "GET";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // boxContent
            // 
            this.boxContent.Location = new System.Drawing.Point(43, 244);
            this.boxContent.Multiline = true;
            this.boxContent.Name = "boxContent";
            this.boxContent.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.boxContent.Size = new System.Drawing.Size(506, 243);
            this.boxContent.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 523);
            this.Controls.Add(this.boxContent);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.boxValue);
            this.Controls.Add(this.boxParameter);
            this.Controls.Add(this.boxURL);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox boxURL;
        private System.Windows.Forms.TextBox boxParameter;
        private System.Windows.Forms.TextBox boxValue;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.TextBox boxContent;
    }
}


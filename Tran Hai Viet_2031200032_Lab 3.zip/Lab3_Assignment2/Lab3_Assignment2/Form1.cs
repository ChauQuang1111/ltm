﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3_Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            HttpClient client = new HttpClient();

            try
            {
                var responseString = await client.GetStringAsync(boxURL.Text.ToString());
                boxContent.AppendText(responseString+Environment.NewLine);
            }
            catch(HttpRequestException ex) {
                boxContent.AppendText(ex.Message);
            }
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_3_Assignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnResolve_Click(object sender, EventArgs e)
        {
            boxIP.Clear();
            IPAddress[] addresses = Dns.GetHostAddresses(boxURL.Text);
            foreach(IPAddress address in addresses)
            {
                boxIP.AppendText(address.ToString()+Environment.NewLine);
            }
        }
    }
}

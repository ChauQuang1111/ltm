﻿namespace Lab_3_Assignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.boxURL = new System.Windows.Forms.TextBox();
            this.btnResolve = new System.Windows.Forms.Button();
            this.boxIP = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // boxURL
            // 
            this.boxURL.Location = new System.Drawing.Point(38, 92);
            this.boxURL.Multiline = true;
            this.boxURL.Name = "boxURL";
            this.boxURL.Size = new System.Drawing.Size(382, 31);
            this.boxURL.TabIndex = 0;
            // 
            // btnResolve
            // 
            this.btnResolve.Location = new System.Drawing.Point(593, 92);
            this.btnResolve.Name = "btnResolve";
            this.btnResolve.Size = new System.Drawing.Size(134, 31);
            this.btnResolve.TabIndex = 1;
            this.btnResolve.Text = "Resolve";
            this.btnResolve.UseVisualStyleBackColor = true;
            this.btnResolve.Click += new System.EventHandler(this.btnResolve_Click);
            // 
            // boxIP
            // 
            this.boxIP.Location = new System.Drawing.Point(38, 159);
            this.boxIP.Multiline = true;
            this.boxIP.Name = "boxIP";
            this.boxIP.Size = new System.Drawing.Size(689, 198);
            this.boxIP.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.boxIP);
            this.Controls.Add(this.btnResolve);
            this.Controls.Add(this.boxURL);
            this.Name = "Form1";
            this.Text = "DNS System";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox boxURL;
        private System.Windows.Forms.Button btnResolve;
        private System.Windows.Forms.TextBox boxIP;
    }
}


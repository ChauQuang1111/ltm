namespace Lab_1
{
    public partial class Assignment1 : Form
    {
        public Assignment1()
        {
            InitializeComponent();
        }

        private void Stream_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.FilterIndex = 1;

            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                pathName.Text = ofd.FileName;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            String filePath = pathName.Text;
            if (!String.IsNullOrEmpty(filePath))
            {
                if (File.Exists(filePath))
                {
                    try
                    {
                        using (StreamReader sr = new StreamReader(filePath))
                        {
                            string fileContent = sr.ReadToEnd();
                            boxContent.Text = fileContent;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            String filePath = pathName.Text;
            if (!String.IsNullOrEmpty(filePath))
            {
                if (File.Exists(filePath))
                {
                    try
                    {
                        using (StreamWriter sw = new StreamWriter(filePath))
                        {
                            sw.Write(boxContent.Text);
                        }
                        MessageBox.Show("File saved successfully");
                        boxContent.Clear();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist");
            }
        }
    }
}

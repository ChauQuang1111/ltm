﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1
{
    public partial class Assignment2 : Form
    {
        public Assignment2()
        {
            InitializeComponent();
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.FilterIndex = 1;

            DialogResult result = ofd.ShowDialog();
            if (result == DialogResult.OK)
            {
                boxPath.Text = ofd.FileName;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private Encoding getEncoding()
        {
            if (radioUTF8.Checked==true)
            {
                return Encoding.UTF8;
            }

            else if (radioUnicode.Checked==true)
            {
                return Encoding.Unicode;
            }
            else
            {
                return Encoding.UTF8;
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            String filePath = boxPath.Text;
            if (!String.IsNullOrEmpty(filePath))
            {
                if (File.Exists(filePath))
                {
                    try
                    {
                        Encoding encoding = getEncoding();
                        using (StreamReader sr = new StreamReader(filePath, encoding))
                        {
                            string fileContent = sr.ReadToEnd();
                            boxContent.Text = fileContent;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            String filePath = boxPath.Text;
            if (!String.IsNullOrEmpty(filePath))
            {
                if (File.Exists(filePath))
                {
                    try
                    {
                        Encoding encoding = getEncoding();
                        using (StreamWriter sw = new StreamWriter(filePath,false,encoding))
                        {
                            sw.Write(boxContent.Text);
                        }
                        MessageBox.Show("File saved successfully");
                        boxContent.Clear();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist");
            }
        }
    }
}

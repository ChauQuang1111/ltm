﻿
namespace Lab_1
{
    partial class Assignment2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelEncode = new Label();
            radioUTF8 = new RadioButton();
            radioUnicode = new RadioButton();
            labelPath = new Label();
            boxPath = new TextBox();
            btnBrowse = new Button();
            btnRead = new Button();
            boxContent = new TextBox();
            btnSave = new Button();
            SuspendLayout();
            // 
            // labelEncode
            // 
            labelEncode.AutoSize = true;
            labelEncode.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelEncode.Location = new Point(36, 19);
            labelEncode.Name = "labelEncode";
            labelEncode.Size = new Size(155, 23);
            labelEncode.TabIndex = 0;
            labelEncode.Text = "Select an Encoding";
            // 
            // radioUTF8
            // 
            radioUTF8.AutoSize = true;
            radioUTF8.Checked = true;
            radioUTF8.Location = new Point(36, 56);
            radioUTF8.Name = "radioUTF8";
            radioUTF8.Size = new Size(63, 24);
            radioUTF8.TabIndex = 1;
            radioUTF8.TabStop = true;
            radioUTF8.Text = "UTF8";
            radioUTF8.UseVisualStyleBackColor = true;
            radioUTF8.CheckedChanged += radioButton1_CheckedChanged;
            // 
            // radioUnicode
            // 
            radioUnicode.AutoSize = true;
            radioUnicode.Location = new Point(36, 95);
            radioUnicode.Name = "radioUnicode";
            radioUnicode.Size = new Size(85, 24);
            radioUnicode.TabIndex = 2;
            radioUnicode.Text = "Unicode";
            radioUnicode.UseVisualStyleBackColor = true;
            // 
            // labelPath
            // 
            labelPath.AutoSize = true;
            labelPath.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelPath.Location = new Point(36, 158);
            labelPath.Name = "labelPath";
            labelPath.Size = new Size(74, 23);
            labelPath.TabIndex = 3;
            labelPath.Text = "File Path";
            labelPath.Click += label2_Click;
            // 
            // boxPath
            // 
            boxPath.Location = new Point(36, 197);
            boxPath.Name = "boxPath";
            boxPath.Size = new Size(567, 27);
            boxPath.TabIndex = 4;
            // 
            // btnBrowse
            // 
            btnBrowse.Location = new Point(663, 190);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(107, 40);
            btnBrowse.TabIndex = 5;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = true;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnRead
            // 
            btnRead.Location = new Point(36, 245);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(161, 33);
            btnRead.TabIndex = 6;
            btnRead.Text = "Read from a file";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click;
            // 
            // boxContent
            // 
            boxContent.Location = new Point(36, 297);
            boxContent.Multiline = true;
            boxContent.Name = "boxContent";
            boxContent.Size = new Size(734, 214);
            boxContent.TabIndex = 7;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(36, 532);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(161, 36);
            btnSave.TabIndex = 8;
            btnSave.Text = "Save content to a file";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // Assignment2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 580);
            Controls.Add(btnSave);
            Controls.Add(boxContent);
            Controls.Add(btnRead);
            Controls.Add(btnBrowse);
            Controls.Add(boxPath);
            Controls.Add(labelPath);
            Controls.Add(radioUnicode);
            Controls.Add(radioUTF8);
            Controls.Add(labelEncode);
            Name = "Assignment2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "File Stream and Encoding";
            ResumeLayout(false);
            PerformLayout();
        }



        #endregion

        private Label labelEncode;
        private RadioButton radioUTF8;
        private RadioButton radioUnicode;
        private Label labelPath;
        private TextBox boxPath;
        private Button btnBrowse;
        private Button btnRead;
        private TextBox boxContent;
        private Button btnSave;
    }
}
﻿namespace Lab_1
{
    partial class Assignment1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pathName = new TextBox();
            button1 = new Button();
            label1 = new Label();
            btnRead = new Button();
            label2 = new Label();
            boxContent = new TextBox();
            btnSave = new Button();
            SuspendLayout();
            // 
            // pathName
            // 
            pathName.Location = new Point(29, 55);
            pathName.Name = "pathName";
            pathName.Size = new Size(595, 27);
            pathName.TabIndex = 0;
            pathName.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(674, 50);
            button1.Name = "button1";
            button1.Size = new Size(94, 37);
            button1.TabIndex = 1;
            button1.Text = "Browse";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(29, 20);
            label1.Name = "label1";
            label1.Size = new Size(123, 20);
            label1.TabIndex = 2;
            label1.Text = "File Path to read";
            label1.Click += label1_Click;
            // 
            // btnRead
            // 
            btnRead.Location = new Point(29, 110);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(296, 37);
            btnRead.TabIndex = 3;
            btnRead.Text = "Read the file and show to textbox";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(29, 167);
            label2.Name = "label2";
            label2.Size = new Size(65, 20);
            label2.TabIndex = 4;
            label2.Text = "Content";
            // 
            // boxContent
            // 
            boxContent.Location = new Point(29, 205);
            boxContent.Multiline = true;
            boxContent.Name = "boxContent";
            boxContent.Size = new Size(739, 220);
            boxContent.TabIndex = 5;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(29, 431);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(234, 38);
            btnSave.TabIndex = 6;
            btnSave.Text = "Save Content to a new file";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // Assignment1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 492);
            Controls.Add(btnSave);
            Controls.Add(boxContent);
            Controls.Add(label2);
            Controls.Add(btnRead);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(pathName);
            Name = "Assignment1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Stream Reader and Writer";
            Load += Stream_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox pathName;
        private Button button1;
        private Label label1;
        private Button btnRead;
        private Label label2;
        private TextBox boxContent;
        private Button btnSave;
    }
}

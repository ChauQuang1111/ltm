﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Text.Json;

namespace Lab_1
{
    public partial class Assignment3 : Form
    {

        public class Student
        {
            public String ID { get; set; }
            public String fullName { get; set; }
            public DateTime dob { get; set; }
            public String address { get; set; }
            public string ImagePath { get; set; }

        }
        private Student currentStudent;
        private string imagePath;
        public Assignment3()
        {
            InitializeComponent();
            currentStudent = new Student();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image files (*.jpg, *.jpeg, *.png)|*.jpg; *.jpeg; *.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new System.Drawing.Bitmap(ofd.FileName);
                imagePath = ofd.FileName;
            }
        }

        private void button_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Binary files (*.dat)|*.dat";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(boxStudentId.Text) &&
                    !string.IsNullOrEmpty(boxStudentName.Text) &&
                    !string.IsNullOrEmpty(boxAddress.Text))
                {
                    currentStudent.ID = boxStudentId.Text;
                    currentStudent.fullName = boxStudentName.Text;
                    currentStudent.dob = dateTimePicker1.Value;
                    currentStudent.address = boxAddress.Text;
                    currentStudent.ImagePath=imagePath;

                    // Save student information to the selected file
                    using (BinaryWriter writer = new BinaryWriter(File.Open(saveFileDialog.FileName, FileMode.Create)))
                    {
                        writer.Write(currentStudent.ID);
                        writer.Write(currentStudent.fullName);
                        writer.Write(currentStudent.dob.ToBinary());
                        writer.Write(currentStudent.address);
                        writer.Write(currentStudent.ImagePath);
                    }

                    MessageBox.Show("Student information saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    boxAddress.Clear();
                    boxStudentId.Clear();
                    boxStudentName.Clear();
                    dateTimePicker1.ResetText();
                    pictureBox1.Image = null;
                }
                else
                {
                    MessageBox.Show("Please fill in all student information before saving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Binary files (*.dat)|*.dat";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Read student information from the selected file
                using (BinaryReader reader = new BinaryReader(File.Open(openFileDialog.FileName, FileMode.Open)))
                {
                    currentStudent.ID = reader.ReadString();
                    currentStudent.fullName = reader.ReadString();
                    long ticks = reader.ReadInt64();
                    currentStudent.dob = DateTime.FromBinary(ticks);
                    currentStudent.address = reader.ReadString();
                    currentStudent.ImagePath = reader.ReadString();
                }

                // Display the information in textboxes
                boxStudentId.Text = currentStudent.ID;
                boxStudentName.Text = currentStudent.fullName;
                dateTimePicker1.Value = currentStudent.dob;
                boxAddress.Text = currentStudent.address;

                // Load image if available
                if (!string.IsNullOrEmpty(currentStudent.ImagePath) && File.Exists(currentStudent.ImagePath))
                {
                    pictureBox1.Image = new System.Drawing.Bitmap(currentStudent.ImagePath);
                }
            }

        }

        private void btnReadAndDeserial_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON files (*.json)|*.json";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Deserialize student information from the selected file
                string json;
                using (StreamReader reader = new StreamReader(openFileDialog.FileName))
                {
                    json = reader.ReadToEnd();
                }

                currentStudent = JsonSerializer.Deserialize<Student>(json);

                // Display the information in textboxes
                boxStudentId.Text = currentStudent.ID;
                boxStudentName.Text = currentStudent.fullName;
                dateTimePicker1.Value = currentStudent.dob;
                boxAddress.Text = currentStudent.address;

                // Load image if available
                if (!string.IsNullOrEmpty(currentStudent.ImagePath) && File.Exists(currentStudent.ImagePath))
                {
                    pictureBox1.Image = new System.Drawing.Bitmap(currentStudent.ImagePath);
                }
            }
        }

        private void btnSerialAndSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "JSON files (*.json)|*.json";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                if (!string.IsNullOrEmpty(boxStudentName.Text) &&
                    !string.IsNullOrEmpty(boxStudentId.Text) &&
                    !string.IsNullOrEmpty(boxAddress.Text))
                {
                    currentStudent.ID = boxStudentId.Text;
                    currentStudent.fullName = boxStudentName.Text;
                    currentStudent.dob = dateTimePicker1.Value;
                    currentStudent.address = boxAddress.Text;
                    currentStudent.ImagePath = imagePath;

                    // Serialize and save the current student object to the selected file
                    string json = JsonSerializer.Serialize(currentStudent);
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        writer.Write(json);
                    }

                    MessageBox.Show("Student information serialized and saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    boxAddress.Clear();
                    boxStudentId.Clear();
                    boxStudentName.Clear();
                    dateTimePicker1.ResetText();
                    pictureBox1.Image = null;
                }
                else
                {
                    MessageBox.Show("Please fill in all student information before serializing and saving.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
    


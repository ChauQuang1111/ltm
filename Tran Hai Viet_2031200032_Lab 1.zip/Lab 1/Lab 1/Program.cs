namespace Lab_1
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Assignment1 assignment1 = new Assignment1();
            Assignment2 assignment2 = new Assignment2();
            Assignment3 assignment3 = new Assignment3();
            Application.Run(assignment3);
        }
    }
}
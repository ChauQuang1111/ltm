﻿namespace Lab_1
{
    partial class Assignment3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelStudentId = new Label();
            labelStudentName = new Label();
            labelDOB = new Label();
            labelAddress = new Label();
            boxStudentId = new TextBox();
            boxStudentName = new TextBox();
            boxAddress = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            labelAvatar = new Label();
            pictureBox1 = new PictureBox();
            btnSelectImage = new Button();
            btnReadFile = new Button();
            btnSave = new Button();
            btnReadAndDeserial = new Button();
            btnSerialAndSave = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // labelStudentId
            // 
            labelStudentId.AutoSize = true;
            labelStudentId.Location = new Point(28, 21);
            labelStudentId.Name = "labelStudentId";
            labelStudentId.Size = new Size(79, 20);
            labelStudentId.TabIndex = 0;
            labelStudentId.Text = "Student ID";
            labelStudentId.Click += label1_Click;
            // 
            // labelStudentName
            // 
            labelStudentName.AutoSize = true;
            labelStudentName.Location = new Point(28, 95);
            labelStudentName.Name = "labelStudentName";
            labelStudentName.Size = new Size(76, 20);
            labelStudentName.TabIndex = 1;
            labelStudentName.Text = "Full Name";
            // 
            // labelDOB
            // 
            labelDOB.AutoSize = true;
            labelDOB.Location = new Point(28, 171);
            labelDOB.Name = "labelDOB";
            labelDOB.Size = new Size(94, 20);
            labelDOB.TabIndex = 2;
            labelDOB.Text = "Date of Birth";
            // 
            // labelAddress
            // 
            labelAddress.AutoSize = true;
            labelAddress.Location = new Point(28, 252);
            labelAddress.Name = "labelAddress";
            labelAddress.Size = new Size(62, 20);
            labelAddress.TabIndex = 3;
            labelAddress.Text = "Address";
            // 
            // boxStudentId
            // 
            boxStudentId.Location = new Point(28, 44);
            boxStudentId.Name = "boxStudentId";
            boxStudentId.Size = new Size(301, 27);
            boxStudentId.TabIndex = 4;
            // 
            // boxStudentName
            // 
            boxStudentName.Location = new Point(28, 118);
            boxStudentName.Name = "boxStudentName";
            boxStudentName.Size = new Size(301, 27);
            boxStudentName.TabIndex = 5;
            // 
            // boxAddress
            // 
            boxAddress.Location = new Point(28, 285);
            boxAddress.Multiline = true;
            boxAddress.Name = "boxAddress";
            boxAddress.Size = new Size(301, 107);
            boxAddress.TabIndex = 7;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(28, 194);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(301, 27);
            dateTimePicker1.TabIndex = 8;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // labelAvatar
            // 
            labelAvatar.AutoSize = true;
            labelAvatar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAvatar.Location = new Point(566, 14);
            labelAvatar.Name = "labelAvatar";
            labelAvatar.Size = new Size(69, 28);
            labelAvatar.TabIndex = 9;
            labelAvatar.Text = "Avatar";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(455, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(295, 174);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // btnSelectImage
            // 
            btnSelectImage.Location = new Point(525, 224);
            btnSelectImage.Name = "btnSelectImage";
            btnSelectImage.Size = new Size(160, 48);
            btnSelectImage.TabIndex = 11;
            btnSelectImage.Text = "Select/Change";
            btnSelectImage.UseVisualStyleBackColor = true;
            btnSelectImage.Click += btnSelectImage_Click;
            // 
            // btnReadFile
            // 
            btnReadFile.Location = new Point(28, 411);
            btnReadFile.Name = "btnReadFile";
            btnReadFile.Size = new Size(257, 45);
            btnReadFile.TabIndex = 12;
            btnReadFile.Text = "Read from a file";
            btnReadFile.UseVisualStyleBackColor = true;
            btnReadFile.Click += btnReadFile_Click;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(28, 486);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(257, 45);
            btnSave.TabIndex = 13;
            btnSave.Text = "Save to a file";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += button_Click;
            // 
            // btnReadAndDeserial
            // 
            btnReadAndDeserial.Location = new Point(466, 411);
            btnReadAndDeserial.Name = "btnReadAndDeserial";
            btnReadAndDeserial.Size = new Size(257, 45);
            btnReadAndDeserial.TabIndex = 14;
            btnReadAndDeserial.Text = "Read from a file and Deserialize";
            btnReadAndDeserial.UseVisualStyleBackColor = true;
            btnReadAndDeserial.Click += btnReadAndDeserial_Click;
            // 
            // btnSerialAndSave
            // 
            btnSerialAndSave.Location = new Point(466, 486);
            btnSerialAndSave.Name = "btnSerialAndSave";
            btnSerialAndSave.Size = new Size(257, 45);
            btnSerialAndSave.TabIndex = 15;
            btnSerialAndSave.Text = "Serialize and Save to a file";
            btnSerialAndSave.UseVisualStyleBackColor = true;
            btnSerialAndSave.Click += btnSerialAndSave_Click;
            // 
            // Assignment3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 543);
            Controls.Add(btnSerialAndSave);
            Controls.Add(btnReadAndDeserial);
            Controls.Add(btnSave);
            Controls.Add(btnReadFile);
            Controls.Add(btnSelectImage);
            Controls.Add(pictureBox1);
            Controls.Add(labelAvatar);
            Controls.Add(dateTimePicker1);
            Controls.Add(boxAddress);
            Controls.Add(boxStudentName);
            Controls.Add(boxStudentId);
            Controls.Add(labelAddress);
            Controls.Add(labelDOB);
            Controls.Add(labelStudentName);
            Controls.Add(labelStudentId);
            Name = "Assignment3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Student Management";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelStudentId;
        private Label labelStudentName;
        private Label labelDOB;
        private Label labelAddress;
        private TextBox boxStudentId;
        private TextBox boxStudentName;
        private TextBox boxAddress;
        private DateTimePicker dateTimePicker1;
        private Label labelAvatar;
        private PictureBox pictureBox1;
        private Button btnSelectImage;
        private Button btnReadFile;
        private Button btnSave;
        private Button btnReadAndDeserial;
        private Button btnSerialAndSave;
    }
}